package zad.com;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("wprowadz imie");
        String name = input.nextLine();


        System.out.println("podaj nazwisko");
        String sureName = input.nextLine();

        System.out.println("podaj drugie imie");
        String secondName = input.nextLine();

        System.out.println("wiek" );
        String year = input.nextLine();

        System.out.println("wzrost");
        String high = input.nextLine();

        System.out.println("waga");
        String weight = input.nextLine();

        System.out.println("zwierzak domowy");
        String pet = input.nextLine();

        System.out.println("imie zwierzaka");
        String nameOfPet = input.nextLine();
        System.out.println("Pani nazywa sie " + name + " na drugie imie " + secondName + " a na nazwisko " + sureName
                        +
                " urodzila sie " + year + " wzrost tej pani wynosi " + high + " waga do tego wzrostu wynosi "
                        + weight + " na pytanie, czy ma zwierzaka powiedziala: " + pet + " i ma na imie " +nameOfPet +
                        ".");
    }
}
